<?php

$send ['start']='
👏 Bem vindo ao bot de divulgação aqui você irá divulgar o que quiser.

⚡️ Para começar envie a imagem de perfil do seu canal, grupo ou bot.';

$send ['info']='Código fonte original por @httd1';

$send ['ja_divulgou']='☹️ Desculpe mas você só poderá fazer outra divulgação <b>'.tempo (PROXIMA_DIVULGACAO).'</b> após sua última divulgação.';

$send ['bloqueado']='<b>⚠️ Ops!!
Você excedeu o limite de advertências e não poderá fazer mais nenhuma divulgação no Bot.</b>';

$send ['pede_descricao']='✏️ Agora me envie uma descrição do seu canal grupo ou bot, de preferência abaixo de 250 caracteres.';

$send ['pede_nome']='😀 Também preciso do nome do seu canal.';

$send ['pede_username']='✔️ Ok, para finalizar envie o username do seu canal, grupo ou bot.

👉 <em>Ex:</em> @username';

$send ['finaliza']='✅ Pronto.

Sua divulgação foi enviada para o nosso moderador, você será notificado caso seja divulgado no canal '.CANAL;

$send ['finaliza_divulgacao_direta']='✨ Parabéns, sua divulgação já foi publicada no canal.

🙌 Se quiser você pode nos ajudar divulgando o nosso canal '.CANAL;

$send ['erro_username']='Opa! parece que você errou.
Siga o exemplo:

👉 <em>Ex:</em> @username';

$send ['aceito']='✨ Parabéns, sua divulgação foi aceita e já foi publicada no canal.

🙌 Se quiser você pode nos ajudar divulgando o nosso canal '.CANAL;

$send ['refazer']='<b>😃 Certo.

Vamos fazer tudo de novo, comece enviando uma imagem.</b>';

$send ['so_membros']='<b>☺️ Opa!!
Antes de tudo se torne um membro do nosso canal, só assim você poderá divulgar aqui.</b>';
